

// Loader 
//------------------------------------------------------------------------------------------

$(window).load(function() {
	$("#loader").fadeOut();
	$("#mask").delay(1000).fadeOut("slow");
});



// Add and Remove class 
//------------------------------------------------------------------------------------------

$(document).scroll(function() {
		if ($(document).scrollTop() >= 1) {
		  $('.header-area, .mainInner .content-header, .inner-page-banner, .banner_area').addClass('fixed');
		} else {
		  $('.header-area, .mainInner .content-header, .inner-page-banner, .banner_area').removeClass('fixed');
		}
	});




var startProductBarPos=-1;
    window.onscroll=function(){
        var bar = document.getElementById('MenuBar');
        if(startProductBarPos<0)startProductBarPos=findPosY(bar);

        if(pageYOffset>startProductBarPos){
            bar.style.position='fixed';
            bar.style.top=0;
        }else{
            bar.style.position='relative';
        }

    };


    function findPosY(obj) {
        var curtop = 0;
        if (typeof (obj.offsetParent) != 'undefined' && obj.offsetParent) {
            while (obj.offsetParent) {
                curtop += obj.offsetTop;
                obj = obj.offsetParent;
            }
            curtop += obj.offsetTop;
        }
        else if (obj.y)
            curtop += obj.y;
        return curtop;
    }







// Scroll Up 
//------------------------------------------------------------------------------------------

	$(window).scroll(function(){
	    if ($(this).scrollTop() > 100) {
	        $('.scrollup').fadeIn();
	    } else {
	        $('.scrollup').fadeOut();
	    }
	});

	$('.scrollup').click(function(){
	    $("html, body").animate({ scrollTop: 0 }, 600);
	    return false;
	});


// gallery 
//------------------------------------------------------------------------------------------

$(function(){
      $('.portfolio, package-gallery').magnificPopup({
        delegate: 'a',
        type: 'image',
        image: {
          cursor: null,
          titleSrc: 'title'
        },
        gallery: {
          enabled: true,
          preload: [0,1], // Will preload 0 - before current, and 1 after the current image
          navigateByImgClick: true
        }
      });
    });

// Book Now Popup 
//------------------------------------------------------------------------------------------

$(function() {
  
  // contact form animations
  $('.booknowbtn').click(function() {
    $('#BookNowForm').fadeToggle();
  })
  $(document).mouseup(function (e) {
    var container = $("#BookNowForm");

    if (!container.is(e.target) // if the target of the click isn't the container...
        && container.has(e.target).length === 0) // ... nor a descendant of the container
    {
        container.fadeOut();
    }
  });
  
});

// Nav 
//------------------------------------------------------------------------------------------

 
$(function(){
      var menuwidth  = 240; // pixel value for sliding menu width
      var menuspeed  = 400; // milliseconds for sliding menu animation time
  
      var $bdy       = $('body');
      var $container = $('body');
      var $burger    = $('#side-panel-menu');
    var negwidth   = "-"+menuwidth+"px";
      var poswidth   = menuwidth+"px";
  
      $('#mob-menu').on('click',function(e){
      if($bdy.hasClass('openmenu')) {
        jsAnimateMenu('close');
      } else {
        jsAnimateMenu('open');
      }
     });
  
   $('.overlay').on('click', function(e){
        if($bdy.hasClass('openmenu')) {
        jsAnimateMenu('close');
        }
     });
  
     $('a[href$="#"]').on('click', function(e){
        e.preventDefault();
     });
  
     function jsAnimateMenu(tog) {
      if(tog == 'open') {
          $bdy.addClass('openmenu');
      
          $container.animate({marginRight: negwidth, marginLeft: poswidth}, menuspeed);
        $burger.animate({width: poswidth}, menuspeed);
          $('.overlay').animate({left: poswidth}, menuspeed);
        }
    
     if(tog == 'close') {
          $bdy.removeClass('openmenu');
      
        $container.animate({marginRight: "0", marginLeft: "0"}, menuspeed);
          $burger.animate({width: "0"}, menuspeed);
          $('.overlay').animate({left: "0"}, menuspeed);
       }
      }

        $(".menu li").on('click',function(){
        if (!$(this).hasClass("active")) {
        $(".menu li.active").removeClass("active");
        $(this).addClass("active");
        }
      });

        $('.menu li.sub').on('click', function(){
               $(this).toggleClass('current').siblings().removeClass('current');
        });

        $('.menu li').on('click', function(){
               $(this).siblings().removeClass('current');
        });



        
   });

    
(function() {

    "use strict";

    var toggles = document.querySelectorAll(".c-hamburger");

    for (var i = toggles.length - 1; i >= 0; i--) {
      var toggle = toggles[i];
      toggleHandler(toggle);
    };

    function toggleHandler(toggle) {
      toggle.addEventListener( "click", function(e) {
        e.preventDefault();
        (this.classList.contains("is-active") === true) ? this.classList.remove("is-active") : this.classList.add("is-active");
      });
    }

  })();




// smooth scrolling
//------------------------------------------------------------------------------------------
$('a[href*="#"]')
  // Remove links that don't actually link to anything
  .not('[href="#"]')
  .not('[href="#0"]')
  .click(function(event) {
    // On-page links
    if (
      location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') 
      && 
      location.hostname == this.hostname
    ) {
      // Figure out element to scroll to
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
      // Does a scroll target exist?
      if (target.length) {
        // Only prevent default if animation is actually gonna happen
        event.preventDefault();
        $('html, body').animate({
          scrollTop: target.offset().top
        }, 1000, function() {
          // Callback after animation
          // Must change focus!
          var $target = $(target);
          $target.focus();
          if ($target.is(":focus")) { // Checking if the target was focused
            return false;
          } else {
            $target.attr('tabindex','-1'); // Adding tabindex for elements not focusable
            $target.focus(); // Set focus again
          };
        });
      }
    }
  });



// Animations 
//------------------------------------------------------------------------------------------


jQuery(document).ready(function() {

  var v_count = '0';

  jQuery(window).load(function() {
        
    jQuery('.animated').fadeTo(0,0);
    jQuery('.animated').each(function(){
    var imagePos = jQuery(this).offset().top;
    var timedelay = jQuery(this).attr('data-delay');
    
    var topOfWindow = jQuery(window).scrollTop();
      if (imagePos < topOfWindow+300) {
        jQuery(this).fadeTo(1,500);
        $anim = jQuery(this).attr('data-animation');
      }
    });
    

  });
    
  jQuery(window).scroll(function() {  
  
  
    jQuery('.animated').each(function(){
    var imagePos = jQuery(this).offset().top;
    var timedelay = jQuery(this).attr('data-delay');
    
    var topOfWindow = jQuery(window).scrollTop();
      if (imagePos < topOfWindow+500) {   
        jQuery(this).delay(timedelay).queue(function(){
          jQuery(this).fadeTo(1,500);
          $anim = jQuery(this).attr('data-animation');
          jQuery(this).addClass($anim).clearQueue();
        });
        
      }
    });
  
  });


  });



// Float menu
//------------------------------------------------------------------------------------------


var topMargin  = 380;
         var slideTime  = 1200;
         var ns6 = (!document.all && document.getElementById); 
         var ie4 = (document.all);
         var ns4 = (document.layers);
         var ie6 = (document.documentElement);
         window.setInterval("main()", 10); 

        function floatObject() { 
         findHt = (ns6||ns4) ? innerHeight : document.body.clientHeight;
        } 

        function main() { 
        if (ns4) { 
         this.currentY  = document.floatLayer.top; 
         this.scrollTop = window.pageYOffset;
         mainTrigger();
         } else if(ns6) {
         this.currentY = parseInt(document.getElementById('floatLayer').style.top); 
         this.scrollTop = scrollY;
          mainTrigger(); 
         } else if(ie4) { 
         this.currentY  = floatLayer.style.pixelTop;
         this.scrollTop = document.body.scrollTop; 
         mainTrigger();
          } 
         } 
         function mainTrigger() { 
         var newTargetY = this.scrollTop + this.topMargin; 
         if ( this.currentY != newTargetY ) { 
         if ( newTargetY != this.targetY ) { 
         this.targetY = newTargetY;
          floatStart(); 
          } 
          animator(); 
          } 
          } 
          function floatStart() { 
          var now = new Date(); 
          this.A    = this.targetY - this.currentY; 
          this.B    = Math.PI / ( 2 * this.slideTime ); 
          this.C    = now.getTime(); 
          if (Math.abs(this.A) > this.findHt) { 
          this.D = this.A > 0 ? this.targetY - this.findHt : this.targetY + this.findHt; 
          this.A = this.A > 0 ? this.findHt : -this.findHt; 
          } else {   
          this.D = this.currentY; 
           } 
          } 
          function animator() { 
          var now = new Date(); 
          var newY  = this.A * Math.sin( this.B * ( now.getTime() - this.C ) ) + this.D; 
          newY    = Math.round(newY); 
          if (( this.A > 0 && newY > this.currentY ) || ( this.A < 0 && newY < this.currentY )) { 
          if ( ie4 )floatLayer.style.pixelTop = newY; 
          if ( ns4 )document.floatLayer.top = newY;
          if ( ns6 )document.getElementById('floatLayer').style.top = newY + "px"; 
          } 
         } 
        function setVisibility(id, visibility) {
        document.getElementById(id).style.display = visibility;

        }
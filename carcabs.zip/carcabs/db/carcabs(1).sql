-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2017 at 05:58 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carcabs`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `id` tinyint(1) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `username`, `password`, `active`) VALUES
(1, 'admin', 'e10adc3949ba59abbe56e057f20f883e', 1);

-- --------------------------------------------------------

--
-- Table structure for table `gallery_images`
--

CREATE TABLE `gallery_images` (
  `id` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  `date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery_images`
--

INSERT INTO `gallery_images` (`id`, `image`, `date_time`) VALUES
(1, '9a0a8029b6ca165aa4c38139d669593b.jpg', '2017-09-10 22:05:38'),
(2, '18400e55dda171a4ae3081068e13e0fe.jpg', '2017-09-10 22:05:38'),
(3, '647c075d3ad9778c2e29d138897c0b84.jpg', '2017-09-10 22:05:38'),
(4, '4c8e8a5be8ed892fe5144e1376fe800b.jpg', '2017-09-10 22:05:38');

-- --------------------------------------------------------

--
-- Table structure for table `news_events`
--

CREATE TABLE `news_events` (
  `id` int(11) NOT NULL,
  `title` varchar(220) NOT NULL,
  `description` text NOT NULL,
  `event_date` date NOT NULL,
  `image` varchar(100) NOT NULL,
  `status` tinyint(2) NOT NULL,
  `date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news_events`
--

INSERT INTO `news_events` (`id`, `title`, `description`, `event_date`, `image`, `status`, `date_time`) VALUES
(2, 'sample tests', 'hey ram', '2017-09-07', '8beb56f567159814d79d5be96230a6e1.jpg', 1, '2017-09-10 18:52:49'),
(3, 'slider2', 'sample ', '2017-09-28', 'd0225c9d8cbff1d276b87db3fd4e7abd.jpg', 1, '2017-09-14 18:27:31'),
(4, 'slider2', 'sample ', '2017-09-27', '08ace1445433e7b1d7de424b6f113e29.jpg', 1, '2017-09-16 12:36:50'),
(5, 'sample test', 'sample', '2017-09-20', 'e0ea3a1965445180b7ab6d467f680161.jpg', 1, '2017-09-16 12:37:03');

-- --------------------------------------------------------

--
-- Table structure for table `package`
--

CREATE TABLE `package` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `price` varchar(30) NOT NULL,
  `overview` text NOT NULL,
  `included` text NOT NULL,
  `destinations` text NOT NULL,
  `date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `package`
--

INSERT INTO `package` (`id`, `title`, `price`, `overview`, `included`, `destinations`, `date_time`) VALUES
(1, 'sample testss', '10005', 'sample testds', 'sampleaa', 'sample test ggsf', '2017-09-09 15:01:26'),
(2, 'new sample', '1000', 'sample test ', 'new sample', 'temp sample', '2017-09-14 18:26:24'),
(3, 'Transactional mail activation', '500', 'sample test', 'sample', 'test sample', '2017-09-14 18:27:09'),
(4, 'new sample', 'sample package', 'sample', 'test ', 'dump', '2017-09-16 12:36:36');

-- --------------------------------------------------------

--
-- Table structure for table `package_images`
--

CREATE TABLE `package_images` (
  `id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `package_images`
--

INSERT INTO `package_images` (`id`, `package_id`, `image`) VALUES
(1, 1, 'f8efd9af4d8587129b15482d479e46ee.jpg'),
(2, 1, '4de2cd24ae4a6244097f7249f94faad5.jpg'),
(3, 1, '4d5e6f67a925b865b5e68d5a4c34c8f7.jpg'),
(4, 2, 'ac816173ac8383c35fea600276bdebc0.jpg'),
(5, 2, '0b68a7629081d3ddfed05df81402a5b2.jpg'),
(6, 2, '9e27bf6994f0ea28ee28ead7c7969e7a.jpg'),
(7, 2, 'c3e4cc00b0b7c96c95c04840eb7ab88c.jpg'),
(8, 3, '0f0d2230a1bf9ba77c7a0179969288ae.jpg'),
(9, 3, 'a07fdb8d7c1c1ce39216995d778c6860.jpg'),
(10, 4, 'c78a9589d6559b58094eb59f4c905bd7.jpg'),
(11, 4, 'bf708c5cd849478a908dee264fe7d720.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gallery_images`
--
ALTER TABLE `gallery_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news_events`
--
ALTER TABLE `news_events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `package`
--
ALTER TABLE `package`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `package_images`
--
ALTER TABLE `package_images`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gallery_images`
--
ALTER TABLE `gallery_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `news_events`
--
ALTER TABLE `news_events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `package`
--
ALTER TABLE `package`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `package_images`
--
ALTER TABLE `package_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 
	
class Common_model extends CI_Model {
	
	function __construct() {
		// Call the Model constructor 
		parent::__construct();  
			
	} 

	public function insertToTable($arr,$table){

		if(empty($arr))return false;
		if(!$table)return false;
		$this->db->insert($table,$arr);			
		$ID = $this->db->insert_id();
		return $ID;
		
	}


	public function updateTable($arr,$table,$where){
		if(empty($arr)) return false;
		if(!$table)	return false;
		if(!$where)	return false;
		$this->db->where($where);	
		$this->db->update($table,$arr);
		return true;
				 
	}

	public function gettablecount($table){

		$qry    =   "SELECT count(*) as row_count from ".$table ;
		$query  =   $this->db->query($qry);
		$out    =   $query->row_array();
		return $out["row_count"] ;
	}


	public function gettablelist($table){
		$query = $this->db->get($table);
		return $query->result_array(); 
			
	}

	
	public function gettablerow($table,$id,$field){
        $query = $this->db->where($field,$id);	   
		$query = $this->db->get($table);
		
		if($query->num_rows()==0)
			return $query->num_rows();
		else 
			return $query->row_array();
			
	}


	public function gettableobject($table,$id,$field){
        $query = $this->db->where($field,$id);	   
		$query = $this->db->get($table);
		$result = $query->result();
		$row = $result[0];
		
		if($query->num_rows()==0)
			return $query->num_rows();
		else 
			return $row;
			
	}


	public function gettablearray($table,$id,$field){
        $query = $this->db->where($field,$id);	   
		$query = $this->db->get($table);
		
		if($query->num_rows()==0)
			return $query->num_rows();
		else 
			return $query->result_array();
			
	}

	public function getmultipletablerow($table,$where){
        $query = $this->db->where($where);	   
		$query = $this->db->get($table);
		
		
		if($query->num_rows()==0)
			return $query->num_rows();
		else 
			return $query->row_array();
			
	}

		
    public function gettableoptionlist($table,$where,$sortkey,$sort,$num,$offset){

        if($where)
        $query = $this->db->where($where); 
        if($sortkey)    
        $query = $this->db->order_by($sortkey,$sort);
        if($num)
        $this->db->limit($num, $offset);

        $query = $this->db->get($table);
       
        if($query->num_rows()==0)
            return $query->num_rows();
        else 
            return $query->result_array();
            
    }


     function row_delete($where,$table){

     $query = $this->db->where($where);	   
	 $query = $this->db->delete($table);
     return true;
    }   


    function get_package_withimages($num,$offset,$id){

		  $this->db->select('u.*,r.image');
		  $this->db->from('package u');	
		  $this->db->join('package_images r','r.package_id = u.id', 'left');
		  if($id)
		  $this->db->where("u.id",$id);
		  
		  if($num)		 
		  $this->db->limit($num, $offset);
		
          if($id=="")
		  $this->db->group_by('u.id'); 

		  $query = $this->db->get();

		  if($id)	
		  	return $query->row_array();
		  else
		  return $query->result_array();
		}	

	 

}
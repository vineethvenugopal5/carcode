<?php
/**
 * **********************************************************************************
 * @package    member
 * @name       Budgets
 * @version    1.0
 * @author     vineeth
 * @copyright  2012 Newagesmb (http://www.newagesmb.com), All rights reserved.
 * Created on  05-June-2012
 *
 * This script is a part of Codeigniter Framework.
 * Copying, Modifying or Distributing this software and its documentation (with or
 * without modification, for any purpose, with or without fee or royality) is not
 * permitted.
 *
 ***********************************************************************************/

 if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Adminlogin_model extends CI_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }   
    
    function getData($username,$passwrd){
			//Query the data table for every record and row
        $newpasswrd=md5($passwrd);

	       $query =  $this->db->query("SELECT * FROM admin_login WHERE username ='".$username."' AND password='".$newpasswrd."'");
			$output = $query->result();
			return $output[0];
	 }

     function delete($id,$table,$folder){

       
        $sql_1 = "SELECT * FROM ".$table." WHERE id =".$id ;
        $result = $this->db->query($sql_1);
        $data=$result->row_array();

        if($id){
            $sql = "DELETE FROM ".$table." WHERE id = ".$id ;
            $result = $this->db->query($sql);
        }

        if($data['image']){     
        if(file_exists(DIR_UPLIMG_PATH.$folder."/".$data['image'])) 
                unlink(DIR_UPLIMG_PATH.$folder."/".$data['image']);
        }

        return true;
    }

    




   

		
    

}
?>
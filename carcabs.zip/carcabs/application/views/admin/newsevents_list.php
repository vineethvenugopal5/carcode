
<script language="javascript">
	$(document).ready(function(){
	
	
	//Change Limit of pagination
	$('#limit').change(function(){
		$("#userMasterForm").attr("action", "<?php echo site_url("admin/adminnews");?>" );
		$("#userMasterForm").submit();return true;
	});
	// END: Change Limit of pagination


	// filter function
	$("#filter_button").click(function(){
		$("#userMasterForm").submit();return true;
	});
	
});

	




</script>
  <?php
if($this->session->flashdata('message')) {
$message = $this->session->flashdata('message');

?>
<div class="alert alert-success alert-dismissable" style="margin-top:5px; width: 800px;margin-left: 290px;"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><?php echo $message; ?></div>
<?php
}

?>


  <div id="page-wrapper">
<div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"><?php echo $title ?></h1>
                </div>
  <div class="col-md-4">
             
</div>
          <div class="col-md-8" id="search_div">
      
         </div>
        
                 <div class="panel-body">
                            <div class="dataTable_wrapper">

          <form name="userMasterForm" method="post" action="" id="userMasterForm">
  			

				  <table class="table table-striped table-bordered table-hover" id="dataTables-example">

								<tr></tr>
								<tr><td class="div_blok_in_top" colspan="9" height="35"><div class="div_blok_in_top_rte"></div>
									<div class="div_blok_in_top_lft">
									<a style=" width: 90px; float: right;" href="<?php echo base_url();?>admin/adminnews/add_news" class="form-control btn-primary" >Add New</a>
                                
                                  </div>
									</div>
									</td>
								</tr>
								
								  <tr>
										<th width="2%" height="32">No.</th>
										<th width="15%">Title</th>
										<th width="15%">Event Date</th>
										<th width="5%">Edit</th>
										<th width="5%">Delete</th>
                                      
                                      
								 </tr>


							 <?php if($news !=""){
							for($i=0;$i<sizeof($news);$i++){
							$val =  $news[$i];

							?> 
							 <tr class="odd gradeX">
								<td><?php echo $_REQUEST['per_page']+$i+1; ?></td>
                             
								<td ><?php echo $val['title'];?></td>
								<td ><?php echo $val['event_date'];?></td>
								 <td ><a href="<?php echo site_url("admin/adminnews/edit_news/".$val['id']);?>"> <span class="glyphicon glyphicon-edit"></span></a></td>
								                            
								 <td><a href="<?php echo site_url("admin/adminnews/delete_news/".$val['id']);?>" onclick="return confirm('Are you sure you want to delete this item?');"><span class="glyphicon glyphicon-remove"></span></a></td>
                              
							</tr>
							<?php } ?>
							<tr>
												<td colspan="10" align="center" height="36" >
													<div class="div_blok_in_btm">
														<div class="div_blok_in_btm_list">
															<div class="pagination_main" ><?php echo $this->pagination->create_links(); ?></div>
														</div>
														<span style="float:right; padding-top:18px;">
													<select name="limit" id="limit" class="form-control" style="width:80px;">
														<option value="5" <?php if($_REQUEST['limit'] == 5){?> selected="selected"<?php } ?> >5</option>
														<option value="10" <?php if($_REQUEST['limit'] == 10){?> selected="selected"<?php } ?> >10</option>
														<option value="20" <?php if($_REQUEST['limit'] == 20){?> selected="selected"<?php } ?>>20</option>
														<option value="50" <?php if($_REQUEST['limit'] == 50){?> selected="selected"<?php } ?>>50</option>
														<option value="100" <?php if($_REQUEST['limit'] == 100){?> selected="selected"<?php } ?>>100</option>
														<option value="all" <?php if($_REQUEST['limit'] == 'all'){?> selected="selected"<?php } ?>>all</option>
													</select>
													</span>
													</div>
													</td>
											</tr>
							<?php }else{ ?>
							<tr >
							<td colspan="10" align="center" height="40" class="blok02">&nbsp;No data found</td>
							</tr>
							<?php } ?>
						   
						  </table>
		
          </form>
  
   </div>

                        </div>
                <!-- /.col-lg-12 -->
            </div>
            </div>

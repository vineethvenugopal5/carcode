<script type="text/javascript" src="<?php echo site_url()?>assets/js/ajaxupload.3.5.js" ></script>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Add Packages</h1>
                </div>
                <div class="panel-body">
                   <?php
if($this->session->flashdata('msg')) {
$message = $this->session->flashdata('msg');

?>
<div class="alert alert-danger alert-dismissable" style="margin-top:90px;"><?php echo $message; ?></div>
<?php
}

?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <form role="form" action="" enctype="multipart/form-data" method="POST" name="myForm" >
                                        <div class="form-group">
                                            <label>Package Title</label>
                                            <input class="form-control" type="text" name="title" value="<?php echo $package['title'];?>" required="required">
                                          
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Price</label>
                                           <input class="form-control" type="text" name="price" value="<?php echo $package['price'];?>" required="required">
                                            
                                        </div>
                                        <div class="form-group">
                                            <label>Package Overview</label>
                                            <textarea rows="4" cols="50" class="form-control" name="overview" ><?php echo $package['overview'];?></textarea>
                                            
                                        </div>
                                      
                                          <div class="form-group">
                                            <label>Package Included</label>
                                            <textarea rows="4" cols="50" class="form-control" name="included" ><?php echo $package['included'];?></textarea>
                                            
                                        </div>

                                        <div class="form-group">
                                            <label>Package Destinations</label>
                                            <textarea rows="4" cols="50" class="form-control" name="destination" ><?php echo $package['destinations'];?></textarea>
                                            
                                        </div>
                                        
                                         <div class="form-group">
                                           <div class="row">
                                          <label>Package Images:</label>
                                          <div class="inputs">
                                           <input name="uploadfile" type="file" id="uploads" >
                                         
                                            <span id="status"></span>	
                                               <ul id="file">
                                                 <?php if($package_images!=""){ 
for($i=0;$i<count($package_images);$i++){ 

 $package_id= explode(".",$package_images[$i]['image']);?>

<li class="up" id="img_<?php echo $package_id[0];?>" style="margin:10px 10px 10px 10px;float:left;">

<img src="<?php echo site_url(); ?>uploads/packages/<?php echo $package_images[$i]['image'];?>" alt="" height="50" width="50" />
                                                <br><a onclick="return confirm('Are you sure you want to delete this item?');" href="javascript:removeImage('<?php echo $package_images[$i]['image'];?>','<?php echo $package_images[$i]['id'];?>');" class="small">Remove</a>
                        <input type="hidden" class="image_upload" name="images[]" id="image_<?php echo $package_images[$i]['image'];?>" value="<?php echo $package_images[$i]['image'];?>" />

                        <input type="hidden" name="image_id[]" value="<?php echo $package_images[$i]['id'];?>" />
</li>
<?php } ?>
<?php } ?>

                                               </ul>
                                               
                                        </div>
                                                                
                                        </div>
                                        
                                        <div class="form-group">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                        </div>
                                       
                                    </form>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            
        <!-- /#page-wrapper -->

    </div>
    
      <script type="text/javascript" >

$(document).ready(new function() {

		$(function(){
			var btnUpload=$('#uploads');
			var status=$('#status');
			new AjaxUpload(btnUpload, {
				action: '<?php echo site_url('admin/adminpackage/uploadfile'); ?>',
				name: 'uploadfile',
				onSubmit: function(file, ext){
					 if (! (ext && /^(jpg|png|jpeg|gif)$/.test(ext))){ 
						// extension is not allowed 
						status.text('Only JPG, PNG or GIF files are allowed');
						return false;
					}
					status.text('Uploading...');
				},
				onComplete: function(file, response){
					//On completion clear the status
					status.text('');
					
					//Add uploaded file to list
					 if(response == "error"){
						$('<li class="up" id='+parseInt($('#upload li').length)+'></li>').appendTo('#file').html('<span style="color:#FF0000;">error- Maximum image size is 2 Mb</span>\n\
                                                <br><a href="javascript:removeLi(\''+parseInt($('#upload li').length)+'\');" class="small">Remove</a>').addClass('error');
												
					}
					 else{
						var image = response.split('.');
						$('<li class="up" id="img_'+image[0]+'" style="margin:10px 10px 10px 10px;float:left;"></li>').appendTo('#file').html('<img src="<?php echo site_url(); ?>uploads/packages/'+response+'" alt="" height="50" width="50" />\n\
                                                <br><a onclick="return confirm(\'Are you sure you want to delete this item?\');" href="javascript:removeImage(\''+response+'\',\'0\');" class="small">Remove</a>\n\
												<input type="hidden" class="image_upload" name="new_images[]" id="image_'+response+'" value="'+response+'" />');
						                        
												
								
					}
				}
			});
			
		});
	});



function removeImage(img,ID){

  if(ID=="")
  var ID = "";
   
	var image = img.split('.');
		$.ajax({
				type: "POST",    
			
				url: "<?php echo site_url("admin/adminpackage/removeImage");?>",
				data: { image: img,table:'package_images',id:ID },
				success: function( msg ) {

								
					if(msg){
						$('#img_'+image[0]).remove();
						
					}
				}
		});
	}


	
</script>
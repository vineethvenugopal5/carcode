<!-- Navigation -->
<style type="text/css">
    .sidebar{
        margin-top: 90px;

    }
    .logo{
        padding-left: 20px; 
    }

    #thumbwrap {
    margin:75px auto;
    width:252px; height:252px;
}

</style>
<body>

    <div id="wrapper">
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0;height:110px;" >
            <div class="navbar-header">

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
                 <a class="navbar-brand" href="<?php echo base_url('admin/adminhome/index'); ?>">
                    <img class="img-responsive" src="<?php echo base_url('assets'); ?>/images/logo.png" alt="Car Cabs" >
                </a>
            </div>
            <!-- /.navbar-header -->
           
            <ul class="nav navbar-top-links navbar-right">
               
                               
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                       
                        <li><a href="<?php echo base_url('admin/adminlogin/logout'); ?>"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->
        
            <div class="navbar-default sidebar" role="navigation" style="margin-top: 114px;">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                         
                            <!-- /input-group -->
                        

                        </li>

                          <li>
                           <a href="<?php echo base_url('admin/adminpackage');?>"><i class="fa fa-outdent" aria-hidden="true"></i> Package</a>
                        </li>
                         <li>
                           <a href="<?php echo base_url('admin/adminnews');?>"> <i class="fa fa-newspaper-o" aria-hidden="true"></i> News and Events </a>
                        </li>
                         <li>
                           <a href="<?php echo base_url('admin/admingallery');?>"> <i class="fa fa-picture-o" aria-hidden="true"></i> Gallery </a>
                        </li>

                        
                      
                        
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

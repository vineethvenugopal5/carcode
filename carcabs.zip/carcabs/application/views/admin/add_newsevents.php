<script type="text/javascript" src="<?php echo site_url()?>assets/js/ajaxupload.3.5.js" ></script>

<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Add News and Events</h1>
                </div>
                <div class="panel-body">
                   <?php
if($this->session->flashdata('msg')) {
$message = $this->session->flashdata('msg');

?>
<div class="alert alert-danger alert-dismissable" style="margin-top:90px;"><?php echo $message; ?></div>
<?php
}

?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <form role="form" action="" enctype="multipart/form-data" method="POST" name="myForm">
                                        <div class="form-group">
                                            <label>News and Events Title</label>
                                            <input class="form-control" type="text" name="title" value="" required="required">
                                          
                                        </div>
                                        
                                       
                                        <div class="form-group">
                                            <label>Description</label>
                                            <textarea rows="4" cols="50" class="form-control" name="description" ></textarea>
                                            
                                        </div>
                                      
                                        <div class="form-group">
                                            <label>News and Events Date</label>
                                            <input class="form-control" type="text" id="new_datepicker" name="events_date" value="" >
                                          
                                        </div>

                                        
                                        
                                         <div class="form-group">
                                           <div class="row">
                                          <label>News and Events Images:</label>
                                          <div class="inputs">
                                           <input name="uploadfile" type="file" id="uploads" >
                                         
                                            <span id="status"></span>	
                                               <ul id="file"></ul>
                                               
                                        </div>
                                                                
                                        </div>
                                         <input type="hidden" id="upload_image">
                                        <div class="form-group">
                                        <button type="submit" class="btn btn-primary" >Submit</button>
                                        </div>
                                       
                                    </form>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            
        <!-- /#page-wrapper -->

    </div>
    
         <script type="text/javascript" >

$(document).ready(new function() {

    $(function(){
      var btnUpload=$('#uploads');
      var status=$('#status');
      new AjaxUpload(btnUpload, {
        action: '<?php echo site_url('admin/adminnews/uploadfile'); ?>',
        name: 'uploadfile',
        onSubmit: function(file, ext){
           if (! (ext && /^(jpg|png|jpeg|gif)$/.test(ext))){ 
            // extension is not allowed 
            status.text('Only JPG, PNG or GIF files are allowed');
            return false;
          }
          status.text('Uploading...');
        },
        onComplete: function(file, response){
          //On completion clear the status
          status.text('');
          
          //Add uploaded file to list
           if(response == "error"){
            $('<li class="up" id='+parseInt($('#upload li').length)+'></li>').appendTo('#file').html('<span style="color:#FF0000;">error- Maximum image size is 2 Mb</span>\n\
                                                <br><a href="javascript:removeLi(\''+parseInt($('#upload li').length)+'\');" class="small">Remove</a>').addClass('error');
                        
          }
           else{
            var image = response.split('.');
            $('<li class="up" id="image_0"></li>').appendTo('#file').html('<img src="<?php echo site_url(); ?>/uploads/news/'+response+'" alt="" height="50" width="50" />\n\
                                                <br><a onclick="return confirm(\'Are you sure you want to delete this item?\');" href="javascript:removeImage(\''+response+'\',\'0\');" class="small">Remove</a>\n\
                        <input type="hidden" name="image" id="image_'+response+'" value="'+response+'" />') 
                        $('#uploads').hide();
                        
                
          }
        }
      });
      
    });
  });



function removeImage(img,ID){
   
  
    $.ajax({
        type: "POST",    
      
        url: "<?php echo site_url("admin/adminnews/removeImage");?>",
        data: { image: img },
        success: function( msg ) {
                
          if(msg){
            $('#image_0').remove();
             $("#uploads").show();
            
            
          }
        }
    });
  }

 $( "#new_datepicker" ).datepicker({
   format: 'yyyy-mm-dd'
});

</script>
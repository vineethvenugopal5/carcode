<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class adminlogin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function adminlogin()
	{
		 parent::__construct();
		
		$this->load->library('session');
		 $this->load->helper(array('form', 'url'));
	}
	
	public function index()
	{
	    if ($this->session->userdata('logged_in') == TRUE)
	    {
	        redirect('admin/adminhome');
	    }
	   
	   
		$this->load->view('admin/header');
		$this->load->view('admin/login');
		$this->load->view('admin/footer');
		
	}
	
	public function process_login()
	{   
	   
		$username = $this->input->post('username');    
	    $password = $this->input->post('password');
	
		$this->load->model('adminlogin_model');
		$data['result']  = $this->adminlogin_model->getData($username,$password);  
		if ($data['result']->active == 1)
	    {  
		 
	        $data = array(
                   'username'  => $username,
				   'user_id'  => $data['result']->id,
				   'is_admin'  => $data['result']->active,
				   'logged_in' => TRUE
				  
            );

           
			  
            $this->session->set_userdata($data);
            redirect('admin/adminhome/index');
	    } 
	    else 
	    {
	        $this->session->set_flashdata('message', 'Username or Password is not correct');
	        redirect('admin/adminlogin/index');
	    }
	}
	
	public function logout()
	{
	    $this->session->sess_destroy();
	    redirect('admin/adminlogin');
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/** 
 * Home Class
 *
 * This class is used to mange blog module.
 *
 * @package		Application
 * @subpackage	Controllers
 * @category	Controller  
 * @author		vineeth <> 
 */  

class Adminhome extends CI_Controller {

    public function __construct() {

            parent::__construct();
            $this->load->model('Adminlogin_model');
            $this->load->model('Common_model'); 

            // Your own constructor code
   		
     }

	public function index(){
	
	
        $head['HEADER'] = "Carcabs-Admin Home "; 

    
        if ($this->session->userdata('logged_in') != TRUE){
	        redirect('admin/adminlogin/index');
	     }
	   
        $this->load->view('admin/header');
        $this->load->view('admin/nav');
		$this->load->view('admin/home');
	    $this->load->view('admin/footer');

	}
	

		
}



/* End of file home.php */

/* Location: ./application/controllers/home.php */
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/** 
 * Home Class
 *
 * This class is used to mange blog module.
 *
 * @package		Application
 * @subpackage	Controllers
 * @category	Controller  
 * @author		vineeth <> 
 */  

class Adminnews extends CI_Controller {

    public function __construct() {

            parent::__construct();
           
            $this->load->model('Common_model'); 
            $this->load->library('form_validation');
            $this->load->library('pagination');

            // Your own constructor code
   		
     }

	public function index(){
	
	
        $head['HEADER'] = "Carcabs-Admin News & Events "; 

    
        if ($this->session->userdata('logged_in') != TRUE){
	        redirect('admin/adminlogin/index');
	     }

	     $page_limit = 20;		

		$_REQUEST['limit'] = (!$_POST['limit'] ? ($_GET['limit'] ? $_GET['limit'] :$page_limit):$_POST['limit']);
		$_REQUEST['s'] = (!$_POST['s'] ? ($_GET['s'] ? addslashes($_GET['s']) :''):addslashes($_POST['s']));
		$_REQUEST['per_page'] = (!$_POST['per_page'] ? ($_GET['per_page'] ? $_GET['per_page'] :''):$_POST['per_page']);
		
		// END : set default values
		
		// Creating params
		$params = '?t=1';
		if($_REQUEST['limit']) $params .= '&limit='.$_REQUEST['limit'];
		if($_REQUEST['s']) $params .= '&s='.$_REQUEST['s'];

		 
		$config['base_url'] = site_url("admin/adminnews/index")."/".$params;

		$table= 'news_events';
		$config['total_rows'] = $this->Common_model->gettablecount($table);
		
		$config['per_page'] = $_REQUEST['limit'] == 'all' ? $config['total_rows']:$_REQUEST['limit'];
		//$config['use_page_numbers'] = TRUE;
		$config['page_query_string'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = '&laquo';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = '&raquo';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        
		$this->pagination->initialize($config);
        $data['title'] = 'Admin News & Events Listing';
        //fetching contest list
        $data['news'] = $this->Common_model->gettableoptionlist($table,'','','',$config['per_page'],$_REQUEST['per_page']);
      
	
        $this->load->view('admin/header');
        $this->load->view('admin/nav');
		$this->load->view('admin/newsevents_list',$data);
	    $this->load->view('admin/footer');

	}


	function add_news(){

    	 if ($this->session->userdata('logged_in') != TRUE){
	        redirect('admin/adminlogin/index');
	     }

         
		
	     
	   if($_SERVER['REQUEST_METHOD'] == 'POST') { 	
		
	     $this->form_validation->set_rules('title', ' Tame', 'trim|required');
	   
	   
	     if ($this->form_validation->run() == TRUE){

	     	  $data   = array(
                            "title" => $this->input->post("title"),
                            "description"  => $this->input->post("description"),
                            "event_date"  => $this->input->post("events_date"),
                            "image"  => $this->input->post("image"),
                            "status"  =>1
                            );

	     	   $news_id = $this->Common_model->insertToTable($data,'news_events');
	     	   
			$this->session->set_flashdata('message', 'Created/Updated succesfully! ','Success');
			redirect("admin/adminnews");
		  }else{
               
               $this->session->set_flashdata('msg', 'Title Required! ','Failure');
			redirect("admin/adminnews/add_news");

		  }
	   
	     }
	    $this->load->view('admin/header');
        $this->load->view('admin/nav');
	    $this->load->view('admin/add_newsevents',$data);
	    $this->load->view('admin/footer');
				
  
     } 



     function edit_news(){

    	 if ($this->session->userdata('logged_in') != TRUE){
	        redirect('admin/adminlogin/index');
	     }

      	  $id = $this->uri->segment(4); 

		  if($id!=""){
      	  $data['news'] = $this->Common_model->gettablerow('news_events',$id,'id');
      	 	
      	  }   

      	
	    if($_SERVER['REQUEST_METHOD'] == 'POST') { 	
		
	     $this->form_validation->set_rules('title', ' Title', 'trim|required'); 
	   
	         if ($this->form_validation->run() == TRUE){

	         
	     	    $data   = array(
                            "title" => $this->input->post("title"),
                            "description"  => $this->input->post("description"),
                            "event_date"  => $this->input->post("events_date"),
                            "image"  => $this->input->post("image"),
                            "status"  =>1
                            );



	     	    $where = array('id' =>$id);
                $package = $this->Common_model->updateTable($data,'news_events',$where);

			  $this->session->set_flashdata('message', 'Updated succesfully! ','Success');
			  redirect("admin/adminnews");
		     }
	   
	     }

	   
	    $this->load->view('admin/header');
        $this->load->view('admin/nav');
	    $this->load->view('admin/edit_newevents',$data);
	    $this->load->view('admin/footer');
				
  
     } 


     public function delete_news($news_id){

	 	 if ($this->session->userdata('logged_in') != TRUE){
	        redirect('admin/adminlogin/index');
	     }

          $news = $this->Common_model->gettablerow('news_events',$news_id,'id');

                if(!empty($news['image'])){
	                
                     if(file_exists(DIR_UPLIMG_PATH."news/".$news['image']))
				      unlink(DIR_UPLIMG_PATH."news/".$news['image']);
	 
                 }


            $where = array('id' =>$news_id);
            $this->Common_model->row_delete($where,'news_events');


            $this->session->set_flashdata('message', 'Deleted succesfully! ','Success');
	       redirect("admin/adminnews");
     }



     public function uploadfile(){

          
            $file = basename($_FILES['uploadfile']['name']);
            $tmpname = $_FILES['uploadfile']['tmp_name'];
            $img_size = $_FILES['uploadfile']['size'];
            $imageCaption = $_POST['imageCaption']?$_POST['imageCaption']:'';
            $path_parts = pathinfo($file);
            $image_extension = $path_parts['extension'];
            $img_ext = strtolower($image_extension);
            $image_name = md5(time());

            if($img_size < 2097152) {
            $uploadName = DIR_UPLIMG_PATH."/news/".$image_name.".".$img_ext;
            copy($tmpname, $uploadName) ;
            $image = $image_name.".".$img_ext;
            echo $image; 
           

             }
                 
    }



    public function removeImage($id=''){
	  	
	 	$image = $_POST['image']?$_POST['image']:'';
	 	$table = $_POST['table']?$_POST['table']:'';
	 	$id = $_POST['id']?$_POST['id']:'';

	 	if($id){
	 		$data = array('image' =>"");
	 		$where = array('id' =>$id);
	 		$this->Common_model->updateTable($data,$table,$where);
		
	 	}
			
		
		if($image){					
			if(file_exists(DIR_UPLIMG_PATH."news/".$image))
				unlink(DIR_UPLIMG_PATH."news/".$image);
		}
		echo "success";
	}


	

		
}



/* End of file home.php */

/* Location: ./application/controllers/home.php */
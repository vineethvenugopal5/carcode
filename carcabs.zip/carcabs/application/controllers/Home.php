<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/** 
 * Home Class
 *
 * This class is used to mange blog module.
 *
 * @package		Application
 * @subpackage	Controllers
 * @category	Controller  
 * @author		vineeth <> 
 */  

class Home extends CI_Controller {

    public function __construct() {

            parent::__construct();

            $this->load->model('Common_model'); 
            $this->load->library('pagination');
            
            // Your own constructor code
   		
     }

     public function index(){

     	$head['HEADER'] = "Car Cabs";  

     	$data['news'] = $this->Common_model->gettableoptionlist('news_events','','','',2,0);
     	$data['gallery'] = $this->Common_model->gettableoptionlist('gallery_images','','','',8,0);
     	$data['packages'] = $this->Common_model->get_package_withimages(3,0,'');

	   
        $this->load->view('common/header',$head);
		$this->load->view('frontend/home',$data);
		$this->load->view('common/footer');

	}

	public function about(){
	
	
        $head['HEADER'] = "Car Cabs-About Us";   
	 	    
        $this->load->view('common/header',$head);
		$this->load->view('frontend/about');
		$this->load->view('common/footer');

	}

	public function services(){
	
	
        $head['HEADER'] = "Car Cabs-services";   
	 	    
        $this->load->view('common/header',$head);
		$this->load->view('frontend/services');
		$this->load->view('common/footer');

	}

	public function packages(){
	
	
        $head['HEADER'] = "Car Cabs-Packages";   

        $page_limit = 9;

        $_REQUEST['limit'] = (!$_POST['limit'] ? ($_GET['limit'] ? $_GET['limit'] :$page_limit):$_POST['limit']);
		$_REQUEST['s'] = (!$_POST['s'] ? ($_GET['s'] ? addslashes($_GET['s']) :''):addslashes($_POST['s']));
		$_REQUEST['per_page'] = (!$_POST['per_page'] ? ($_GET['per_page'] ? $_GET['per_page'] :''):$_POST['per_page']);
		
		// END : set default values
		
		// Creating params
		$params = '?t=1';
		if($_REQUEST['limit']) $params .= '&limit='.$_REQUEST['limit'];
		if($_REQUEST['s']) $params .= '&s='.$_REQUEST['s'];

		 
		$config['base_url'] = site_url("packages")."/".$params;

		$table= 'package';
		$config['total_rows'] = $this->Common_model->gettablecount($table);
		
		$config['per_page'] = $_REQUEST['limit'] == 'all' ? $config['total_rows']:$_REQUEST['limit'];
		//$config['use_page_numbers'] = TRUE;
		$config['page_query_string'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = '&laquo';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = '&raquo';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        
		$this->pagination->initialize($config);

        $data['packages'] = $this->Common_model->get_package_withimages($config['per_page'],$_REQUEST['per_page'],'');		
	 	    
        $this->load->view('common/header',$head);
		$this->load->view('frontend/packages',$data);
		$this->load->view('common/footer');

	}

	public function package_detail($id){

		$id = $this->uri->segment(3); 

		 $head['HEADER'] = "Car Cabs-Packages";

		if($id!="")
      	$data['package_detail']= $this->Common_model->gettablerow('package',$id,'id');
      	$data['package_image']= $this->Common_model->gettablearray('package_images',$id,'package_id');
 	
        $this->load->view('common/header',$head);
		$this->load->view('frontend/package_detail',$data);
		$this->load->view('common/footer');

	}

	public function news_events(){
	
	
        $head['HEADER'] = "Car Cabs-News and Events";


         $page_limit = 10;		

		$_REQUEST['limit'] = (!$_POST['limit'] ? ($_GET['limit'] ? $_GET['limit'] :$page_limit):$_POST['limit']);
		$_REQUEST['s'] = (!$_POST['s'] ? ($_GET['s'] ? addslashes($_GET['s']) :''):addslashes($_POST['s']));
		$_REQUEST['per_page'] = (!$_POST['per_page'] ? ($_GET['per_page'] ? $_GET['per_page'] :''):$_POST['per_page']);
		
		// END : set default values
		
		// Creating params
		$params = '?t=1';
		if($_REQUEST['limit']) $params .= '&limit='.$_REQUEST['limit'];
		if($_REQUEST['s']) $params .= '&s='.$_REQUEST['s'];

		 
		$config['base_url'] = site_url("news")."/".$params;

		$table= 'news_events';
		$config['total_rows'] = $this->Common_model->gettablecount($table);
		
		$config['per_page'] = $_REQUEST['limit'] == 'all' ? $config['total_rows']:$_REQUEST['limit'];
		//$config['use_page_numbers'] = TRUE;
		$config['page_query_string'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = '&laquo';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = '&raquo';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        
		$this->pagination->initialize($config);
        
        //fetching contest list
        $data['news'] = $this->Common_model->gettableoptionlist($table,'','','',$config['per_page'],$_REQUEST['per_page']);
         
	 	    
        $this->load->view('common/header',$head);
		$this->load->view('frontend/news_events',$data);
		$this->load->view('common/footer');

	}


	public function gallery(){
	
	
        $head['HEADER'] = "Car Cabs-Gallery"; 
        $data['gallery'] = $this->Common_model->gettablelist('gallery_images');
	 	    
        $this->load->view('common/header',$head);
		$this->load->view('frontend/gallery',$data);
		$this->load->view('common/footer');

	}



	public function contact(){
	
	
        $head['HEADER'] = "Car Cabs-Contact Us";   
	 	    
        $this->load->view('common/header',$head);
		$this->load->view('frontend/contact');
		$this->load->view('common/footer');

	}


	 public function booknow(){

	 	if($_SERVER['REQUEST_METHOD'] == 'POST') { 	

	 	$name = $this->input->post("name");
        $email  = $this->input->post("email");
        $contact_number  = $this->input->post("contact");
        $service  = $this->input->post("service");
                           
            
         $message = '<table width="400" border="0">
		  <tr>
		    <td width="150">Name:</td>
		    <td>'.$name.'</td>
		  </tr>

		  <tr>
		    <td>Email:</td>
		    <td>'.$email.'</td>
		  </tr>

		  <tr>
		    <td>Contact Number:</td>
		    <td>'.$contact_number.'</td>
		  </tr>

		   <tr>
		    <td>Sevice:</td>
		    <td>'.$service.'</td>
		  </tr>

		  </table>';


              $this->load->library('email');
              $config = $this->config->item('mail');
              $this->email->initialize($config);               
              $this->email->from($email , $name);
              $this->email->to('workwithsameesha@gmail.com');
              $this->email->subject("Car Cabs - Book Now");
              $this->email->message($message);
              $this->email->send();

            $this->session->set_flashdata('msg', 'Booked Succesfully! ','Success');
			redirect();

		}
     }


public function contact_message(){

	 	if($_SERVER['REQUEST_METHOD'] == 'POST') { 	

	 	$name = $this->input->post("name");
        $email  = $this->input->post("email");
        $contact_number  = $this->input->post("contact");
        $service  = $this->input->post("service");
        $message  = $this->input->post("message");
                           
            
         $message = '<table width="400" border="0">
		  <tr>
		    <td width="150">Name:</td>
		    <td>'.$name.'</td>
		  </tr>

		  <tr>
		    <td>Email:</td>
		    <td>'.$email.'</td>
		  </tr>

		  <tr>
		    <td>Contact Number:</td>
		    <td>'.$contact_number.'</td>
		  </tr>

		   <tr>
		    <td>Sevice:</td>
		    <td>'.$service.'</td>
		  </tr>
		  <tr>
		    <td>Message:</td>
		    <td>'.$message.'</td>
		  </tr>

		  </table>';


              $this->load->library('email');
              $config = $this->config->item('mail');
              $this->email->initialize($config);               
              $this->email->from($email , $name);
              $this->email->to('workwithsameesha@gmail.com');
              $this->email->subject("Car Cabs - Contact Us");
              $this->email->message($message);
              $this->email->send();

            $this->session->set_flashdata('msg', 'Updated Succesfully! ','Success');
			redirect('contact');

		}
     }


      public function package_detail_booknow(){

	 	if($_SERVER['REQUEST_METHOD'] == 'POST') { 	

	 	$name = $this->input->post("name");
        $email  = $this->input->post("email");
        $contact_number  = $this->input->post("contact");
        $title  = $this->input->post("title");
        $message  = $this->input->post("message");
        $id  = $this->input->post("id");
                           
            
         $message = '<table width="400" border="0">
		  <tr>
		    <td width="150">Name:</td>
		    <td>'.$name.'</td>
		  </tr>

		  <tr>
		    <td>Email:</td>
		    <td>'.$email.'</td>
		  </tr>

		  <tr>
		    <td>Contact Number:</td>
		    <td>'.$contact_number.'</td>
		  </tr>

		   <tr>
		    <td>Sevice:</td>
		    <td>'.$tite.'</td>
		  </tr>

		   <tr>
		    <td>Message:</td>
		    <td>'.$message.'</td>
		  </tr>

		  </table>';


              $this->load->library('email');
              $config = $this->config->item('mail');
              $this->email->initialize($config);               
              $this->email->from($email , $name);
              $this->email->to('workwithsameesha@gmail.com');
              $this->email->subject("Car Cabs - Book Now");
              $this->email->message($message);
              $this->email->send();

            $this->session->set_flashdata('msg', 'Booked Succesfully! ','Success');
			redirect('home/package_detail/'.$id);

		}
     }




	
		
}



/* End of file home.php */

/* Location: ./application/controllers/home.php */